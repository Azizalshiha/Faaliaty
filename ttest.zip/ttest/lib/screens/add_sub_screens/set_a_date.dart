import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:ttest/shared/const.dart';

class set_a_date extends StatefulWidget {
  const set_a_date({Key? key}) : super(key: key);

  @override
  _set_a_dateState createState() => _set_a_dateState();
}

class _set_a_dateState extends State<set_a_date> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(


    );
  }
}
